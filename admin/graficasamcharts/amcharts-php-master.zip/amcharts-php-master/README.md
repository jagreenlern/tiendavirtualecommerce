amcharts-php v0.3
============

amcharts-php enables you to create amcharts in PHP. 

# Examples
Using amcharts-php is very easy and requires only a few lines of code. There are 4 examples of different chart types in the ```examples``` directory. 

# Docs
If you're not familiar with amcharts javascript charts, check out the [API reference](http://docs.amcharts.com/3/javascriptcharts) and the [example](http://www.amcharts.com/javascript-charts/). 
